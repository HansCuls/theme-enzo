const colors = require('tailwindcss/colors');

// "Dark Modern Glass" palette — 50-400 stay solid opaque (body text, light
// borders need full contrast), 500-900 shift toward blue-violet and pick up
// alpha so every existing bg-neutral-700/800/900 usage across the app
// automatically becomes a frosted-glass surface without touching each file.
const gray = {
    50: 'hsl(216, 33%, 97%)',
    100: 'hsl(214, 15%, 91%)',
    200: 'hsl(210, 16%, 82%)',
    300: 'hsl(211, 13%, 65%)',
    400: 'hsl(211, 10%, 53%)',
    500: 'hsla(230, 14%, 46%, 0.85)',
    600: 'hsla(232, 18%, 32%, 0.7)',
    700: 'hsla(235, 28%, 18%, 0.5)',
    800: 'hsla(238, 32%, 11%, 0.55)',
    900: 'hsla(240, 38%, 7%, 0.65)',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#0d0b1f',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: colors.violet,
                gray: gray,
                neutral: gray,
                cyan: colors.cyan,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
