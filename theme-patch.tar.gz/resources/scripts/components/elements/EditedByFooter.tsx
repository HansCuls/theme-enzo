import React from 'react';
import styled from 'styled-components/macro';
import tw from 'twin.macro';

const FooterBadge = styled.a`
    ${tw`fixed bottom-4 right-4 z-30 flex flex-col items-end px-3 py-2 rounded-xl`};
    ${tw`bg-neutral-800 backdrop-blur-md border border-white/10`};
    ${tw`no-underline transition-colors duration-150`};
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.2), 0 4px 6px -4px rgba(0, 0, 0, 0.2);

    &:hover {
        ${tw`border-primary-500/50`};
    }
`;

// Small fixed glass badge, bottom-right, on every screen (auth + dashboard +
// server pages) since it's mounted once at the App root. Links out to Telegram.
const EditedByFooter = () => (
    <FooterBadge href={'https://t.me/enzoxavierr'} target={'_blank'} rel={'noopener noreferrer'}>
        <p css={tw`text-xs text-neutral-200 m-0`}>
            Edited by <span css={tw`text-primary-400 font-semibold`}>Enzoxavier</span>
        </p>
        <p css={tw`text-2xs text-neutral-500 m-0`}>&copy; {new Date().getFullYear()} All rights reserved</p>
    </FooterBadge>
);

export default EditedByFooter;
